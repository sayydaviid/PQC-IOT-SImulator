# Versão compacta para revisão

Abra `sbrc.pdf` para conferir a paginação. Para importar no Overleaf, envie os arquivos deste projeto e selecione `sbrc.tex` como arquivo principal.

As seis seções estão separadas na pasta `sec/`. A revisão foi preparada em uma nova cópia: os arquivos de trabalho em `docs/` e o ZIP anterior não foram substituídos. Use o projeto completo deste ZIP para manter texto e figuras correspondentes.

A conferência de extensão está em `CONFERENCIA.md` e `contagem.json`. Os detalhes técnicos retirados do corpo, tabelas completas e condições dos experimentos estão em `reproducao/`.

A Figura 6 agora apresenta os novos resultados sobre cadeia, identidade nos tickets e leituras por conexão. Os seis arquivos utilizados ficam em `figuras/contexto/artigo/`. Os antigos painéis TLS não são usados nesta versão.

Para regenerar os seis painéis a partir dos dados incluídos (Python com Matplotlib e NumPy):

```sh
python3 reproducao/gerar_figura6.py
```

Compilação:

```sh
pdflatex sbrc.tex
bibtex sbrc
pdflatex sbrc.tex
pdflatex sbrc.tex
```

O script de contagem utiliza PyMuPDF e aponta para os dois PDFs fornecidos no computador de origem. Para executá-lo em outro computador, ajuste os caminhos no dicionário `SOURCES`.
