"""Conta o texto corrido do PDF; fórmulas destacadas e floats ficam separados."""
from pathlib import Path
import re, json
import fitz

ROOT = Path(__file__).resolve().parent
SOURCES = {
    'aceito': Path('/home/tavares/Downloads/5904_Versao_final_de_artigo_aceito (2).pdf'),
    'antes': Path('/home/tavares/Downloads/Retomada_de_Sessões_Pós_Quânticas_em_IoT_sob_Falhas_de_Estado__1_ (1).pdf'),
    'ajustado': ROOT / 'sbrc.pdf',
}

def normalize(text):
    text = re.sub(r'-\s*\n\s*(?=\w)', '', text)
    return ' '.join(text.replace('•','').split())

def count(path):
    sections = {str(i): [] for i in range(1,7)}
    captions = {}; sec = None
    doc = fitz.open(path)
    for page in doc:
        for b in page.get_text('dict')['blocks']:
            lines = b.get('lines',[])
            spans = [s for line in lines for s in line['spans']]
            text = '\n'.join(''.join(s['text'] for s in line['spans']) for line in lines)
            if not text: continue
            if re.match(r'^[1-6]\. ',text) and any(s['font']=='NimbusRomNo9L-Medi' and 12.7<s['size']<13.3 for s in spans):
                sec=text[0];continue
            if text.startswith(('Disponibilidade de Artefatos','Agradecimentos','Referências')):
                sec=None
            cap = re.match(r'^(Figura|Tabela) (\d+)\.\s*',text)
            if cap and any(s['font'].startswith('NimbusSanL-Bold') and 9.5<s['size']<10.5 for s in spans):
                c=normalize(text[cap.end():]);captions[cap[1]+' '+cap[2]]={'caracteres':len(c),'texto':c};continue
            if not sec or re.match(r'^\d+\.\d+',text):continue
            selected=[]
            for line in lines:
                ss=line['spans']
                regular=sum(len(s['text']) for s in ss if s['font'] in ('NimbusRomNo9L-Regu','NimbusRomNo9L-ReguItal','NimbusRomNo9L-MediItal') and 11.5<s['size']<12.5)
                if line['bbox'][0]>140 or regular/max(1,sum(len(s['text']) for s in ss))<.65:continue
                selected.append(''.join(s['text'] for s in ss))
            if selected:sections[sec].append('\n'.join(selected))
    normalized={n:normalize('\n'.join(blocks)) for n,blocks in sections.items()}
    first=doc[0].get_text()
    abstracts={}
    if 'Abstract.' in first and 'Resumo.' in first:
        head=first.split('Abstract.',1)[1].split('1. Introdução',1)[0]
        for name,value in zip(('abstract','resumo'),head.split('Resumo.',1)):
            value=normalize(value)
            abstracts[name]={'caracteres':len(value),'texto':value}
    return {'paginas':len(doc),'corpo':{n:len(text) for n,text in normalized.items()},'resumos':abstracts,'legendas':captions,'texto_contado':normalized}

if __name__=='__main__':
    results={name:count(path) for name,path in SOURCES.items()}
    (ROOT/'contagem.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    for name,r in results.items():
        print(name,'páginas',r['paginas'],'corpo',r['corpo'])
        print('legendas',{k:v['caracteres'] for k,v in r['legendas'].items()})
